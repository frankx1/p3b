//////////////////// ALL ASSIGNMENTS INCLUDE THIS SECTION /////////////////////
//
// Title: HashTable class
// Files: HashTable.java HashTableTest.java
// Course: CS400
//
// Author: Bojun Xu
// Email: bxu57@wisc.edu
// Lecturer's Name: Deb Deppeler
//
//////////////////// PAIR PROGRAMMERS COMPLETE THIS SECTION ///////////////////
//
// Partner Name: /
// Partner Email: /
// Partner Lecturer's Name: /
//
// VERIFY THE FOLLOWING BY PLACING AN X NEXT TO EACH TRUE STATEMENT:
// ___ Write-up states that pair programming is allowed for this assignment.
// ___ We have both read and understand the course Pair Programming Policy.
// ___ We have registered our team prior to the team registration deadline.
//
///////////////////////////// CREDIT OUTSIDE HELP /////////////////////////////
//
// Students who get help from sources other than their partner must fully
// acknowledge and credit those sources of help here. Instructors and TAs do
// not need to be credited here, but tutors, friends, relatives, room mates,
// strangers, and others do. If you received no outside help from either type
// of source, then please explicitly indicate NONE.
//
// Persons: (identify each person and describe their help in detail)
// Online Sources: (identify each URL and describe their assistance in detail)
//
/////////////////////////////// 80 COLUMNS WIDE ///////////////////////////////
/**
 * The HashTable class that use linear probing algorithm to store key and value pairs in an array
 */
public class HashTable<K extends Comparable<K>, V> implements HashTableADT<K, V> {

  /**
   * Inner Node Class that stores key and value pairs
   */
  private class HashNode<K extends Comparable<K>, V> {
    private K key;
    private V value;

    /**
     * Constructor method of the inner class Stores key value as a pair
     */
    public HashNode(K key, V value) {
      this.key = key;
      this.value = value;
    }
  }

  private HashNode<K, V>[] hash_table; // Array used to store the elements
  private int table_size; // length of the array
  private int current_size; // current # of items in the array
  private double loadFactor;
  private double loadFactorThreshold;

  /**
   * Default no-arg constructor set default values for class variables
   */
  @SuppressWarnings("unchecked")
  public HashTable() {
    this.current_size = 0;
    this.table_size = 20;
    this.hash_table = new HashNode[table_size];
    this.loadFactor = 0.7;
  }

  /**
   * Constructor method that sets the table size and load factor threshold
   * 
   * @param initialCapacity     is the initial table size of the hash table
   * @param loadFactorThreshold is customized by the user
   */
  @SuppressWarnings("unchecked")
  public HashTable(int initialCapacity, double loadFactorThreshold) {
    this.table_size = initialCapacity;
    this.loadFactorThreshold = loadFactorThreshold;
    this.hash_table = new HashNode[table_size];
  }

  /**
   * Private helper method to turn key into hash index
   * 
   * @param key is used to transform to hash index
   */
  private int hash_function(K key) {
    return key.hashCode() % table_size;
  }

  /**
   * Add the key,value pair to the data structure and increase the number of keys. If key is null,
   * throw IllegalNullKeyException If key is already in data structure, throw
   * DuplicateKeyException() Rehash if load factor is greater or equal to load factor threshold
   */
  @Override
  public void insert(K key, V value) throws IllegalNullKeyException, DuplicateKeyException {
    if (key == null)
      throw new IllegalNullKeyException();

    // Rehash if load factor is greater or equal to load factor threshold
    if (getLoadFactorThreshold() <= getLoadFactor()) {
      current_size = 0;
      // increase the size of table by 2 and then plus 1
      this.table_size = this.table_size * 2 + 1;
      @SuppressWarnings("unchecked")
      // create a new table with the updated table size
      HashNode<K, V>[] new_table = new HashNode[this.table_size];
      for (int i = 0; i < hash_table.length; i++) {
        if (hash_table[i] != null) {
          int newTableIndex = hash_function(hash_table[i].key); // transform the key to hashcode
          HashNode<K, V> tmpNode = new HashNode<K, V>(hash_table[i].key, hash_table[i].value);
          while (new_table[newTableIndex] != null) {
            if (hash_table[newTableIndex].key.equals(key))
              throw new DuplicateKeyException();
            newTableIndex++;
          }
          new_table[newTableIndex] = tmpNode;
          current_size++;
        }
      }
      this.hash_table = new_table;
    }

    // insert the key to the hashTable
    int index = hash_function(key);
    HashNode<K, V> newNode = new HashNode<K, V>(key, value);
    while (hash_table[index] != null) {
      if (hash_table[index].key.equals(key))
        throw new DuplicateKeyException();
      index++;
    }
    hash_table[index] = newNode;
    current_size++;
  }

  /**
   * If key is found, remove the key,value pair from the hash table decrease number of keys. If key
   * is null, throw IllegalNullKeyException If key is not found, return false
   */
  @Override
  public boolean remove(K key) throws IllegalNullKeyException {
    if (key == null)
      throw new IllegalNullKeyException();

    int index = key.hashCode() % table_size;
    for (index = Math.abs(key.hashCode() % table_size); hash_table[index] != null; index++) {
      if (hash_table[index].key.equals(key)) {
        hash_table[index] = null;
        return true;
      }
    }
    return false;
  }

  /**
   * Returns the value associated with the specified key Does not remove key or decrease number of
   * keys If key is null, throw IllegalNullKeyException If key is not found, throw
   * KeyNotFoundException()
   */
  @Override
  public V get(K key) throws IllegalNullKeyException, KeyNotFoundException {
    if (key == null)
      throw new IllegalNullKeyException();
    int index;
    for (index = Math.abs(key.hashCode() % table_size); hash_table[index] != null; index++) {
      if (hash_table[index].key.equals(key))
        return hash_table[index].value;
    }
    throw new KeyNotFoundException();
  }

  /**
   * Returns the number of key,value pairs in the data structure
   */
  @Override
  public int numKeys() {
    return current_size;
  }

  /**
   * Returns the load factor threshold that was passed into the constructor when creating the
   * instance of the HashTable.
   */
  @Override
  public double getLoadFactorThreshold() {
    return loadFactorThreshold;
  }

  /**
   * Returns the current load factor for this hash table load factor = number of items / current
   * table size
   */
  @Override
  public double getLoadFactor() {
    double numKey = numKeys();
    double capacity = getCapacity();
    this.loadFactor = numKey / capacity;
    return this.loadFactor;
  }

  /**
   * Return the current capacity(table size) of the hash table array When the load factor threshold
   * is reached, the capacity must increase to: 2 * capacity + 1
   */
  @Override
  public int getCapacity() {
    return table_size;
  }

  /**
   * Returns the collision resolution scheme used for this hash table. Implement with one of the
   * following collision resolution strategies. Define this method to return an integer to indicate
   * which strategy.
   * 
   * 1 OPEN ADDRESSING: linear probe 2 OPEN ADDRESSING: quadratic probe 3 OPEN ADDRESSING: double
   * hashing 4 CHAINED BUCKET: array of arrays 5 CHAINED BUCKET: array of linked nodes 6 CHAINED
   * BUCKET: array of search trees 7 CHAINED BUCKET: linked nodes of arrays 8 CHAINED BUCKET: linked
   * nodes of linked node 9 CHAINED BUCKET: linked nodes of search trees
   */
  @Override
  public int getCollisionResolution() {
    return 1; // choose the linear probing algorithm
  }
}